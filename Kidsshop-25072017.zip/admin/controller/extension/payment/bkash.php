<?php 

class ControllerExtensionPaymentBkash extends Controller {

	private $error = array(); 



	public function index() {

		$this->language->load('extension/payment/bkash');



		$this->document->setTitle($this->language->get('heading_title'));

		

		$this->load->model('setting/setting');

			

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$this->model_setting_setting->editSetting('bkash', $this->request->post);				

			

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));

		}


        $data['text_edit'] = $this->language->get('text_edit');
		$data['heading_title'] = $this->language->get('heading_title');
        $data['help_total'] = $this->language->get('help_total');
		$data['text_enabled'] = $this->language->get('text_enabled');

		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['text_all_zones'] = $this->language->get('text_all_zones');

		$data['entry_instruction'] = $this->language->get('entry_instruction');
		$data['keywords_hints'] = $this->language->get('keywords_hints');
		$data['token'] =$this->session->data['token'];


		$data['entry_total'] = $this->language->get('entry_total');	

		$data['entry_order_status'] = $this->language->get('entry_order_status');		

		$data['entry_geo_zone'] = $this->language->get('entry_geo_zone');

		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_total'] = $this->language->get('entry_total');

		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
      
		$data['button_save'] = $this->language->get('button_save');

		$data['button_cancel'] = $this->language->get('button_cancel');



 		if (isset($this->error['warning'])) {

			$data['error_warning'] = $this->error['warning'];
		} else {

			$data['error_warning'] = '';
		}

 		if (isset($this->error['error_instruction'])) {

			$data['error_instruction'] = $this->error['error_instruction'];
		} else {

			$data['error_instruction'] = '';
		}

  		$data['breadcrumbs'] = array();



   		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
   		);

   		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
		);



   		$data['breadcrumbs'][] = array(

       		'text'      => $this->language->get('heading_title'),

			'href'      => $this->url->link('extension/payment/bkash', 'token=' . $this->session->data['token'], true),

      		'separator' => ' :: '

   		);

				

		$data['action'] = $this->url->link('extension/payment/bkash', 'token=' . $this->session->data['token'], true);
		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true);

		

		if (isset($this->request->post['bkash_instruction'])) {

			$data['bkash_instruction'] = $this->request->post['bkash_instruction'];

		} else {

			$data['bkash_instruction'] = $this->config->get('bkash_instruction');

		}
		
		if(!$data['bkash_instruction'])$data['bkash_instruction']='<b>bKash Details: A/C- xxxxxxxx </b>
				<h3>*How to make payment?</h3>
				<ul>
				<li>01. Go to bKash Menu by dialing *247#</li>
				<li>02. Choose \'Payment\'</li>
				<li>03. Enter the business wallet number "xxxxxxx"</li>
				<li>04. Enter the amount you want to pay</li>
				<li>05. Enter a reference against your payment (Enter your order number <strong>{orderId}</strong>)</li>
				<li>06. Enter the counter number (the salesperson at the counter will tell you the number)</li>
				<li>07. Now enter your PIN to confirm </li>
				<li>08. Done! You will get a confirmation SMS</li>
				</ul>';
	

		if (isset($this->request->post['bkash_total'])) {

			$data['bkash_total'] = $this->request->post['bkash_total'];

		} else {

			$data['bkash_total'] = $this->config->get('bkash_total'); 

		} 

				

		if (isset($this->request->post['bkash_order_status_id'])) {

			$data['bkash_order_status_id'] = $this->request->post['bkash_order_status_id'];

		} else {

			$data['bkash_order_status_id'] = $this->config->get('bkash_order_status_id'); 

		} 
	


		$this->load->model('localisation/order_status');

		

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		

		if (isset($this->request->post['bkash_geo_zone_id'])) {

			$data['bkash_geo_zone_id'] = $this->request->post['bkash_geo_zone_id'];

		} else {

			$data['bkash_geo_zone_id'] = $this->config->get('bkash_geo_zone_id'); 

		} 

		

		$this->load->model('localisation/geo_zone');

										

		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		

		if (isset($this->request->post['bkash_status'])) {

			$data['bkash_status'] = $this->request->post['bkash_status'];

		} else {

			$data['bkash_status'] = $this->config->get('bkash_status');

		}

		

		if (isset($this->request->post['bkash_sort_order'])) {

			$data['bkash_sort_order'] = $this->request->post['bkash_sort_order'];

		} else {

			$data['bkash_sort_order'] = $this->config->get('bkash_sort_order');

		}



	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/bkash', $data));

	}



	protected function validate() {

		if (!$this->user->hasPermission('modify', 'extension/payment/bkash')) {

			$this->error['warning'] = $this->language->get('error_permission');

		}

		

		if (!$this->request->post['bkash_instruction']) {

			$this->error['error_instruction'] = $this->language->get('error_instruction');

		}
		

		if (!$this->error) {

			return true;

		} else {

			return false;

		}	

	}

}

?>