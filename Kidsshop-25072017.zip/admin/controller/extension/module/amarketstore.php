<?php
class ControllerExtensionModuleAmarketstore extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/amarketstore');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('amarketstore', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$order_subscription_id = $this->config->get('aliwebstore_sync_order_subscription_id');
			if (!empty($order_subscription_id)) {
				$port = parse_url($this->config->get('aliwebstore_sync_data_sync_url'), PHP_URL_PORT);
				//URL to Web Services
				$url = $this->config->get('aliwebstore_sync_data_sync_url') . "/opencart/aliwebstore/sync-opencart-aliwebstore-load-data.php";
					
				$params = array();
				$params["domain_name"] = HTTPS_CATALOG;
				$params["order_subscription_id"] = $this->config->get('aliwebstore_sync_order_subscription_id');
				$params["ssl_connection"] = $this->config->get('config_secure');
				 
				$this->callWebServicesNoReturn($url, 'POST', $params, $port);
			}
			
			$order_subscription_id = $this->config->get('azonwebstore_sync_order_subscription_id');
			if (!empty($order_subscription_id)) {
				$port = parse_url($this->config->get('azonwebstore_sync_data_sync_url'), PHP_URL_PORT);
				//URL to Web Services
				$url = $this->config->get('azonwebstore_sync_data_sync_url') . "/opencart/amazon/sync-opencart-amazon-load-data.php";
					
				$params = array();
				$params["domain_name"] = HTTPS_CATALOG;
				$params["order_subscription_id"] = $this->config->get('azonwebstore_sync_order_subscription_id');
				$params["ssl_connection"] = $this->config->get('config_secure');
				 
				$this->callWebServicesNoReturn($url, 'POST', $params, $port);
			}
			
			$order_subscription_id = $this->config->get('ebaywebstore_sync_order_subscription_id');
			if (!empty($order_subscription_id)) {
				$port = parse_url($this->config->get('ebaywebstore_sync_data_sync_url'), PHP_URL_PORT);
				//URL to Web Services
				$url = $this->config->get('ebaywebstore_sync_data_sync_url') . "/opencart/ebaywebstore/sync-opencart-ebaywebstore-load-data.php";
					
				$params = array();
				$params["domain_name"] = HTTPS_CATALOG;
				$params["order_subscription_id"] = $this->config->get('ebaywebstore_sync_order_subscription_id');
				$params["ssl_connection"] = $this->config->get('config_secure');
				 
				$this->callWebServicesNoReturn($url, 'POST', $params, $port);
			}
			
			$order_subscription_id = $this->config->get('walmartwebstore_sync_order_subscription_id');
			if (!empty($order_subscription_id)) {
				$port = parse_url($this->config->get('walmartwebstore_sync_data_sync_url'), PHP_URL_PORT);
				//URL to Web Services
				$url = $this->config->get('walmartwebstore_sync_data_sync_url') . "/opencart/walmartwebstore/sync-opencart-walmartwebstore-load-data.php";
					
				$params = array();
				$params["domain_name"] = HTTPS_CATALOG;
				$params["order_subscription_id"] = $this->config->get('walmartwebstore_sync_order_subscription_id');
				$params["ssl_connection"] = $this->config->get('config_secure');
					
				$this->callWebServicesNoReturn($url, 'POST', $params, $port);
			}
			
			$order_subscription_id = $this->config->get('bestbuywebstore_sync_order_subscription_id');
			if (!empty($order_subscription_id)) {
				$port = parse_url($this->config->get('bestbuywebstore_sync_data_sync_url'), PHP_URL_PORT);
				//URL to Web Services
				$url = $this->config->get('bestbuywebstore_sync_data_sync_url') . "/opencart/bestbuywebstore/sync-opencart-bestbuywebstore-load-data.php";
					
				$params = array();
				$params["domain_name"] = HTTPS_CATALOG;
				$params["order_subscription_id"] = $this->config->get('bestbuywebstore_sync_order_subscription_id');
				$params["ssl_connection"] = $this->config->get('config_secure');
					
				$this->callWebServicesNoReturn($url, 'POST', $params, $port);
			}

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
		}
		
		$amarketstore_store_service = $this->config->get('amarketstore_store_service');
		$amarketstore_store_service = isset($amarketstore_store_service)?$amarketstore_store_service:"1";

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_retail'] = $this->language->get('text_retail');
		$data['text_affiliate'] = $this->language->get('text_affiliate');

		$data['entry_store_service'] = $this->language->get('entry_store_service');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/amarketstore', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('extension/module/amarketstore', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

		if (isset($this->request->post['amarketstore_store_service'])) {
			$data['amarketstore_store_service'] = $this->request->post['amarketstore_store_service'];
		} else {
			$data['amarketstore_store_service'] = $amarketstore_store_service;
		}
		
		if (isset($this->request->post['amarketstore_store_target'])) {
			$data['amarketstore_store_target'] = $this->request->post['amarketstore_store_target'];
		} else {
			$data['amarketstore_store_target'] = $this->config->get('amarketstore_store_target');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/amarketstore.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/amarketstore')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	/**
	 * Send the request to Web Servces via Curl
	 * $parameters		-	Array Object
	 * $return			-	Return Object
	 */
	protected function callWebServicesNoReturn($url, $method = 'POST', $params, $port = 443) {
	
		$connection_timeout = 50;
	
		$data = http_build_query($params, '', '&');
	
		// Open a curl session for making the call
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_PORT, $port);
		curl_setopt($curl, CURLOPT_POST, TRUE);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	
		// Tell curl not to return headers, but do return the response
		curl_setopt($curl, CURLOPT_HEADER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, FALSE);
		curl_setopt($curl, CURLOPT_ENCODING, 'UTF-8');
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $connection_timeout);
		curl_setopt($curl, CURLOPT_TIMEOUT, 300);
	
		//spoof information
		$agents = array(
				'Mozilla/5.0 (X11; Linux x86_64; rv:12.0) Gecko/20100101 Firefox/12.0',
				'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:7.0.1) Gecko/20100101 Firefox/7.0.1',
				'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.9) Gecko/20100508 SeaMonkey/2.0.4',
				'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)',
				'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; da-dk) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1'
	
		);
		curl_setopt($curl, CURLOPT_USERAGENT,$agents[array_rand($agents)]);
	
		curl_exec($curl);
	
		curl_close($curl);
	}
}