<?php
/*
 *	location: admin/controller
 */

class ControllerDShopunityMarket extends Controller {
	
	private $codename = 'd_shopunity';
	private $route = 'd_shopunity/market';
	private $extension = array();

	public function __construct($registry) {
		parent::__construct($registry);
		$this->load->model('d_shopunity/mbooth');
		$this->load->model('d_shopunity/account');

		$this->extension = $this->model_d_shopunity_mbooth->getExtension($this->codename);
	}

	public function index(){
		if(!$this->model_d_shopunity_account->isLogged()){
			$this->response->redirect($this->url->link('d_shopunity/account/login', 'token=' . $this->session->data['token'], 'SSL'));
		}

		//documentation http://t4t5.github.io/sweetalert/
		$this->document->addStyle('view/javascript/d_shopunity/library/sweetalert/sweetalert.css');
		$this->document->addScript('view/javascript/d_shopunity/library/sweetalert/sweetalert.min.js');

		$this->document->addStyle('view/stylesheet/shopunity/bootstrap.css');
		$this->document->addStyle('view/stylesheet/d_shopunity/d_shopunity.css');
		$this->document->addScript('view/javascript/d_shopunity/d_shopunity.js');
		
   		$this->load->language('d_shopunity/extension');
   		$this->load->model('d_shopunity/extension');

   		$url = array();
		//REFACTOR
		$filter_data = array();

		$data['search'] = '';
		if(isset($this->request->get['search'])){
			$filter_data['search'] = $this->request->get['search'];
			$data['search'] = $this->request->get['search'];
			$url['search'] = $this->request->get['search'];
		}
		$data['page'] = 1;
		if(isset($this->request->get['page'])){
			$filter_data['page'] = $this->request->get['page'];
			$data['page'] = $this->request->get['page'];
		}
		$data['category_id'] = '';
		if(isset($this->request->get['category_id'])){
			$filter_data['category_id'] = $this->request->get['category_id'];
			$url['category_id'] =  $this->request->get['category_id'];
		}

		if(isset($this->request->get['commercial'])){
			$filter_data['commercial'] = $this->request->get['commercial'];
			$url['commercial'] =  $this->request->get['commercial'];
		}
		
		$filter_data['limit'] = 12;
		$filter_data['status'] = 1;
		$filter_data['published'] = 1;
		$filter_data['store_version'] = VERSION;
		
		$data['extensions'] = $this->model_d_shopunity_extension->getExtensions($filter_data);
		$data['categories'] = $this->load->controller('d_shopunity/market/categories'); 
		$data['search_href'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'], 'SSL');

		$data['all'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'], 'SSL');
		$data['commercial'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'].'&commercial=1', 'SSL');
		$data['free'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'].'&commercial=0', 'SSL');

		$data['prev'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'].'&'.http_build_query($url).'&page='.($data['page']-1), 'SSL');
		$data['next'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'].'&'.http_build_query($url).'&page='.($data['page']+1), 'SSL');

   		$data['content_top'] = $this->load->controller('module/d_shopunity/content_top');
   		$data['content_bottom'] = $this->load->controller('module/d_shopunity/content_bottom');

   		$this->response->setOutput($this->load->view($this->route.'.tpl', $data));
	}

	public function categories(){
		$this->load->model('d_shopunity/category');

		$data['categories'] = $this->model_d_shopunity_category->getCategories();
		foreach($data['categories'] as $key => $category){
			$data['categories'][$key]['href'] = $this->url->link('d_shopunity/market', 'token=' . $this->session->data['token'].'&category_id='. $category['category_id'], 'SSL');
		}

		return $this->load->view($this->route.'_categories.tpl', $data);

	}
}



