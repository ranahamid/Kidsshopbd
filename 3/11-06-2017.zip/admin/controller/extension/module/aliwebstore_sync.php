<?php

if (!defined('_JEXEC'))
    define('_JEXEC', 1);

class ControllerExtensionModuleAliWebStoreSync extends Controller {
	private $error = array(); 
	
	public function index() {
		$this->load->language('extension/module/aliwebstore_sync');
		$this->load->model('setting/setting');

		$this->document->setTitle($this->language->get('heading_title'));

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('aliwebstore_sync', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');

			if (!empty($this->request->post['aliwebstore_sync_order_subscription_id'])) {
				$port = parse_url($this->request->post['aliwebstore_sync_data_sync_url'], PHP_URL_PORT);
				//URL to Web Services
				$url = $this->request->post['aliwebstore_sync_data_sync_url'] . "/opencart/aliwebstore/sync-opencart-aliwebstore-load-data.php";
					
				$params = array();
				$params["domain_name"] = HTTPS_CATALOG;
	            $params["order_subscription_id"] = $this->request->post['aliwebstore_sync_order_subscription_id'];
	            $params["ssl_connection"] = $this->config->get('config_secure');
	            
	            $this->callWebServicesNoReturn($url, 'POST', $params, $port);
			}

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
		}
		
		//Load Languages
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		//Load Order Status
		$this->load->model('localisation/order_status');

		$data_filter = array(); //Emtpy array return all order status
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses($data_filter);
		
		//Load aliwebstore data sync model
		$this->load->model('datasync/aliwebstore_sync');
		$data['cartversioning'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('cartversioning');
		$data['servers'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('server');
		$data['memory_limits'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('memory_limit', 'tid');
		$data['aliwebstore_merchant'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('aliwebstore_merchant');	
		$data['locale'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('aliexpress');
		$data['aliwebstore_condition'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('aliwebstore_condition');
		$data['aliwebstore_sort'] = $this->model_datasync_aliwebstore_sync->getSyncLookup('aliwebstore_sort');

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_none'] = $this->language->get('text_none');
		$data['text_content_top'] = $this->language->get('text_content_top');
		$data['text_content_bottom'] = $this->language->get('text_content_bottom');		
		$data['text_column_left'] = $this->language->get('text_column_left');
		$data['text_column_right'] = $this->language->get('text_column_right');
		
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_aliwebstore_sync_debug_mode'] = $this->language->get('text_aliwebstore_sync_debug_mode');		
		$data['text_aliwebstore_sync_public_key'] = $this->language->get('text_aliwebstore_sync_public_key');
		$data['text_aliwebstore_sync_powered_by'] = $this->language->get('text_aliwebstore_sync_powered_by');
		
		$data['text_aliwebstore_sync_tab_general'] = $this->language->get('text_aliwebstore_sync_tab_general');
		$data['text_aliwebstore_sync_tab_aliwebstore'] = $this->language->get('text_aliwebstore_sync_tab_aliwebstore');
		$data['text_aliwebstore_sync_tab_category'] = $this->language->get('text_aliwebstore_sync_tab_category');
		$data['text_aliwebstore_sync_tab_product'] = $this->language->get('text_aliwebstore_sync_tab_product');
		$data['text_aliwebstore_sync_tab_markup'] = $this->language->get('text_aliwebstore_sync_tab_markup');
		$data['text_aliwebstore_sync_tab_seo'] = $this->language->get('text_aliwebstore_sync_tab_seo');
		$data['text_aliwebstore_sync_tab_misc'] = $this->language->get('text_aliwebstore_sync_tab_misc');
		
		$data['text_opencart'] = $this->language->get('text_opencart');
		$data['text_aliwebstore'] = $this->language->get('text_aliwebstore');
		$data['text_percent'] = $this->language->get('text_percent');
		$data['text_amount'] = $this->language->get('text_amount');
		$data['text_higher'] = $this->language->get('text_higher');
		$data['text_lower'] = $this->language->get('text_lower');

		$data['entry_aliwebstore_sync_cartversion'] = $this->language->get('entry_aliwebstore_sync_cartversion');
		$data['entry_aliwebstore_sync_data_sync_url'] = $this->language->get('entry_aliwebstore_sync_data_sync_url');
		$data['help_aliwebstore_sync_data_sync_url'] = $this->language->get('help_aliwebstore_sync_data_sync_url');
		
		$data['entry_aliwebstore_sync_order_subscription_id'] = $this->language->get('entry_aliwebstore_sync_order_subscription_id');
		$data['help_aliwebstore_sync_order_subscription_id'] = $this->language->get('help_aliwebstore_sync_order_subscription_id');

		$data['entry_aliwebstore_sync_status'] = $this->language->get('entry_aliwebstore_sync_status');
		$data['entry_aliwebstore_sync_server'] = $this->language->get('entry_aliwebstore_sync_server');
		$data['entry_aliwebstore_sync_memory_limit'] = $this->language->get('entry_aliwebstore_sync_memory_limit');
		$data['entry_aliwebstore_sync_debug_mode'] = $this->language->get('entry_aliwebstore_sync_debug_mode');

		$data['entry_aliwebstore_sync_merchant'] = $this->language->get('entry_aliwebstore_sync_merchant');
		$data['entry_aliwebstore_sync_locale'] = $this->language->get('entry_aliwebstore_sync_locale');
		$data['entry_aliwebstore_sync_language'] = $this->language->get('entry_aliwebstore_sync_language');
		$data['entry_aliwebstore_sync_public_key'] = $this->language->get('entry_aliwebstore_sync_public_key');
		$data['entry_aliwebstore_sync_private_key'] = $this->language->get('entry_aliwebstore_sync_private_key');
		$data['entry_aliwebstore_sync_associate_id'] = $this->language->get('entry_aliwebstore_sync_associate_id');
		$data['help_aliwebstore_sync_how_to_url'] = $this->language->get('help_aliwebstore_sync_how_to_url');

		$data['entry_aliwebstore_sync_item_page'] = $this->language->get('entry_aliwebstore_sync_item_page');
		$data['help_aliwebstore_sync_item_page'] = $this->language->get('help_aliwebstore_sync_item_page');
		$data['entry_aliwebstore_sync_keywords'] = $this->language->get('entry_aliwebstore_sync_keywords');
		$data['help_aliwebstore_sync_keywords'] = $this->language->get('help_aliwebstore_sync_keywords');
		$data['entry_aliwebstore_sync_minimum_price'] = $this->language->get('entry_aliwebstore_sync_minimum_price');
		$data['entry_aliwebstore_sync_maximum_price'] = $this->language->get('entry_aliwebstore_sync_maximum_price');
		$data['help_aliwebstore_sync_price'] = $this->language->get('help_aliwebstore_sync_price');
		
		$data['entry_aliwebstore_sync_minimum_commission_rate'] = $this->language->get('entry_aliwebstore_sync_minimum_commission_rate');
		$data['entry_aliwebstore_sync_maximum_commission_rate'] = $this->language->get('entry_aliwebstore_sync_maximum_commission_rate');
		$data['help_aliwebstore_sync_commission_rate'] = $this->language->get('help_aliwebstore_sync_commission_rate');


		$data['entry_aliwebstore_sync_minimum_seller_credit_score'] = $this->language->get('entry_aliwebstore_sync_minimum_seller_credit_score');
		$data['entry_aliwebstore_sync_maximum_seller_credit_score'] = $this->language->get('entry_aliwebstore_sync_maximum_seller_credit_score');
		$data['help_aliwebstore_sync_seller_credit_score'] = $this->language->get('help_aliwebstore_sync_seller_credit_score');
		$data['entry_aliwebstore_sync_sort'] = $this->language->get('entry_aliwebstore_sync_sort');

		$data['entry_aliwebstore_sync_category'] = $this->language->get('entry_aliwebstore_sync_category');
		$data['help_aliwebstore_sync_category'] = $this->language->get('help_aliwebstore_sync_category');
		$data['entry_aliwebstore_sync_item_quantity'] = $this->language->get('entry_aliwebstore_sync_item_quantity');
		$data['help_aliwebstore_sync_item_quantity'] = $this->language->get('help_aliwebstore_sync_item_quantity');
		$data['entry_aliwebstore_sync_tax_class'] = $this->language->get('entry_aliwebstore_sync_tax_class');
		$data['entry_aliwebstore_sync_price_markup'] = $this->language->get('entry_aliwebstore_sync_price_markup');
		$data['help_aliwebstore_sync_price_markup'] = $this->language->get('help_aliwebstore_sync_price_markup');
		$data['entry_aliwebstore_sync_price_markup_override'] = $this->language->get('entry_aliwebstore_sync_price_markup_override');
		$data['entry_aliwebstore_sync_high_low'] = $this->language->get('entry_aliwebstore_sync_high_low');

		$data['entry_aliwebstore_sync_stock_status'] = $this->language->get('entry_aliwebstore_sync_stock_status');		
		$data['entry_aliwebstore_sync_update_product'] = $this->language->get('entry_aliwebstore_sync_update_product');
		$data['entry_aliwebstore_sync_update_product_title'] = $this->language->get('entry_aliwebstore_sync_update_product_title');
		$data['entry_aliwebstore_sync_update_product_desc'] = $this->language->get('entry_aliwebstore_sync_update_product_desc');
		$data['entry_aliwebstore_sync_update_product_sku'] = $this->language->get('entry_aliwebstore_sync_update_product_sku');
		$data['entry_aliwebstore_sync_update_product_upc'] = $this->language->get('entry_aliwebstore_sync_update_product_upc');
		$data['entry_aliwebstore_sync_update_product_price'] = $this->language->get('entry_aliwebstore_sync_update_product_price');
		$data['entry_aliwebstore_sync_update_product_special'] = $this->language->get('entry_aliwebstore_sync_update_product_special');
		$data['entry_aliwebstore_sync_update_product_image'] = $this->language->get('entry_aliwebstore_sync_update_product_image');
		$data['entry_aliwebstore_sync_update_product_to_category'] = $this->language->get('entry_aliwebstore_sync_update_product_to_category');
		$data['entry_aliwebstore_sync_update_product_related'] = $this->language->get('entry_aliwebstore_sync_update_product_related');
		$data['entry_aliwebstore_sync_update_product_specification'] = $this->language->get('entry_aliwebstore_sync_update_product_specification');
		$data['entry_aliwebstore_sync_update_product_option'] = $this->language->get('entry_aliwebstore_sync_update_product_option');
		$data['entry_aliwebstore_sync_show_extra_product_info'] = $this->language->get('entry_aliwebstore_sync_show_extra_product_info');
		$data['entry_aliwebstore_sync_show_search_by_aliwebstore'] = $this->language->get('entry_aliwebstore_sync_show_search_by_aliwebstore');
		$data['entry_aliwebstore_sync_default_search_by_aliwebstore'] = $this->language->get('entry_aliwebstore_sync_default_search_by_aliwebstore');		
		$data['entry_aliwebstore_sync_auto_disabled_product'] = $this->language->get('entry_aliwebstore_sync_auto_disabled_product');
		$data['help_aliwebstore_sync_auto_disabled_product'] = $this->language->get('help_aliwebstore_sync_auto_disabled_product');
		$data['entry_aliwebstore_sync_auto_disabled_product_desc'] = $this->language->get('entry_aliwebstore_sync_auto_disabled_product_desc');
		$data['entry_aliwebstore_sync_enabled_api'] = $this->language->get('entry_aliwebstore_sync_enabled_api');
		$data['entry_aliwebstore_sync_api_key'] = $this->language->get('entry_aliwebstore_sync_api_key');
		$data['entry_aliwebstore_sync_generate_api_key'] = $this->language->get('entry_aliwebstore_sync_generate_api_key');
		$data['entry_aliwebstore_sync_api_key_access'] = $this->language->get('entry_aliwebstore_sync_api_key_access');
		$data['entry_aliwebstore_sync_csv_delimiter'] = $this->language->get('entry_aliwebstore_sync_csv_delimiter');
		$data['entry_aliwebstore_sync_csv_remove'] = $this->language->get('entry_aliwebstore_sync_csv_remove');
		$data['entry_aliwebstore_sync_product_redirect'] = $this->language->get('entry_aliwebstore_sync_product_redirect');
		$data['help_aliwebstore_sync_product_redirect'] = $this->language->get('help_aliwebstore_sync_product_redirect');
		$data['entry_aliwebstore_sync_seo_title'] = $this->language->get('entry_aliwebstore_sync_seo_title');
		$data['entry_aliwebstore_sync_seo_image'] = $this->language->get('entry_aliwebstore_sync_seo_image');
		$data['help_aliwebstore_sync_seo_title'] = $this->language->get('help_aliwebstore_sync_seo_title');
		$data['help_aliwebstore_sync_seo_image'] = $this->language->get('help_aliwebstore_sync_seo_image');
		$data['help_aliwebstore_sync_google_url'] = $this->language->get('help_aliwebstore_sync_google_url');


		$merchat_id = $this->config->get('aliwebstore_sync_merchant_id');
		$merchat_id = isset($merchat_id)?$merchat_id:"AliExpress";

		$tax_class_id = $this->config->get('aliwebstore_sync_tax_class_id');
		$tax_class_id = isset($tax_class_id)?$tax_class_id:0;

		$stock_status_id = $this->config->get('aliwebstore_sync_stock_status');
		$stock_status_id = isset($stock_status_id)?$stock_status_id:7;

		$csv_delimiter = $this->config->get('aliwebstore_sync_csv_delimiter');
		$csv_delimiter = isset($csv_delimiter)?$csv_delimiter:";";
		
		$csv_remove = $this->config->get('aliwebstore_sync_csv_remove');
		$csv_remove = isset($csv_remove)?$csv_remove:"1";

		$price_markup = $this->config->get('aliwebstore_sync_price_markup');
		$price_markup = isset($price_markup)?$price_markup:10;
		
		$seo_title = $this->config->get('aliwebstore_sync_seo_title');
		$seo_title = isset($seo_title)?$seo_title:150;
		
		$seo_image = $this->config->get('aliwebstore_sync_seo_image');
		$seo_image = isset($seo_image)?$seo_image:200;

		$item_page = $this->config->get('aliwebstore_sync_item_page');
		$item_page = isset($item_page)?$item_page:1;
		
		$minimum_price = $this->config->get('aliwebstore_sync_minimum_price');
		$minimum_price = isset($minimum_price)?$minimum_price:1.00;

		$maximum_price = $this->config->get('aliwebstore_sync_maximum_price');
		$maximum_price = isset($maximum_price)?$maximum_price:9999.00;
		
		$minimum_commission_rate = $this->config->get('aliwebstore_sync_minimum_commission_rate');
		$minimum_commission_rate = isset($minimum_commission_rate)?$minimum_commission_rate:0.03;
		
		$maximum_commission_rate = $this->config->get('aliwebstore_sync_maximum_commission_rate');
		$maximum_commission_rate = isset($maximum_commission_rate)?$maximum_commission_rate:0.05;
		
		$minimum_seller_credit_score = $this->config->get('aliwebstore_sync_minimum_seller_credit_score');
		$minimum_seller_credit_score = isset($minimum_seller_credit_score)?$minimum_seller_credit_score:2;
		
		$maximum_seller_credit_score = $this->config->get('aliwebstore_sync_maximum_seller_credit_score');
		$maximum_seller_credit_score = isset($maximum_seller_credit_score)?$maximum_seller_credit_score:5;
		
		$amarketstore_store_service = $this->config->get('amarketstore_store_service');
		$data['amarketstore_store_service'] = isset($amarketstore_store_service)?$amarketstore_store_service:1;
		
		$aliwebstore_sync_auto_disabled_product_desc = $this->config->get('aliwebstore_sync_auto_disabled_product_desc');
		$aliwebstore_sync_auto_disabled_product_desc = isset($aliwebstore_sync_auto_disabled_product_desc)?$aliwebstore_sync_auto_disabled_product_desc:1;
		
		$data['entry_layout'] = $this->language->get('entry_layout');
		$data['entry_position'] = $this->language->get('entry_position');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$data['entry_category'] = $this->language->get('entry_category');
		$data['entry_price_markup'] = $this->language->get('entry_price_markup');
		$data['entry_rate'] = $this->language->get('entry_rate');
		$data['entry_type'] = $this->language->get('entry_type');
		
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_add_module'] = $this->language->get('button_add_module');
		$data['button_add_rule'] = $this->language->get('button_rule_add');
		$data['button_remove'] = $this->language->get('button_remove');
		
		$data['token'] = $this->session->data['token'];
		
 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_cartversion'])) {
			$data['error_aliwebstore_sync_cartversion'] = $this->error['aliwebstore_sync_cartversion'];
		} else {
			$data['error_aliwebstore_sync_cartversion'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_data_sync_url'])) {
			$data['error_aliwebstore_sync_data_sync_url'] = $this->error['aliwebstore_sync_data_sync_url'];
		} else {
			$data['error_aliwebstore_sync_data_sync_url'] = '';
		}

		if (isset($this->request->post['aliwebstore_sync_order_subscription_id'])) {
			$data['aliwebstore_sync_order_subscription_id'] = $this->request->post['aliwebstore_sync_order_subscription_id'];
		} else {
			$data['aliwebstore_sync_order_subscription_id'] = $this->config->get('aliwebstore_sync_order_subscription_id');
		}
		
		if (isset($this->error['aliwebstore_sync_merchant_id'])) {
			$data['error_aliwebstore_sync_merchant_id'] = $this->error['aliwebstore_sync_merchant_id'];
		} else {
			$data['error_aliwebstore_sync_merchant_id'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_locale'])) {
			$data['error_aliwebstore_sync_locale'] = $this->error['aliwebstore_sync_locale'];
		} else {
			$data['error_aliwebstore_sync_locale'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_language'])) {
			$data['error_aliwebstore_sync_language'] = $this->error['aliwebstore_sync_language'];
		} else {
			$data['error_aliwebstore_sync_language'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_public_key'])) {
			$data['error_aliwebstore_sync_public_key'] = $this->error['aliwebstore_sync_public_key'];
		} else {
			$data['error_aliwebstore_sync_public_key'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_private_key'])) {
			$data['error_aliwebstore_sync_private_key'] = $this->error['aliwebstore_sync_private_key'];
		} else {
			$data['error_aliwebstore_sync_private_key'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_associate_id'])) {
			$data['error_aliwebstore_sync_associate_id'] = $this->error['aliwebstore_sync_associate_id'];
		} else {
			$data['error_aliwebstore_sync_associate_id'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_item_page'])) {
			$data['error_aliwebstore_sync_item_page'] = $this->error['aliwebstore_sync_item_page'];
		} else {
			$data['error_aliwebstore_sync_item_page'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_minimum_price'])) {
			$data['error_aliwebstore_sync_minimum_price'] = $this->error['aliwebstore_sync_minimum_price'];
		} else {
			$data['error_aliwebstore_sync_minimum_price'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_maximum_price'])) {
			$data['error_aliwebstore_sync_maximum_price'] = $this->error['aliwebstore_sync_maximum_price'];
		} else {
			$data['error_aliwebstore_sync_maximum_price'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_item_quantity'])) {
			$data['error_aliwebstore_sync_item_quantity'] = $this->error['aliwebstore_sync_item_quantity'];
		} else {
			$data['error_aliwebstore_sync_item_quantity'] = '';
		}
		if (isset($this->error['aliwebstore_sync_price_markup'])) {
			$data['error_aliwebstore_sync_price_markup'] = $this->error['aliwebstore_sync_price_markup'];
		} else {
			$data['error_aliwebstore_sync_price_markup'] = '';
		}

		if (isset($this->error['aliwebstore_sync_seo_title'])) {
			$data['error_aliwebstore_sync_seo_title'] = $this->error['aliwebstore_sync_seo_title'];
		} else {
			$data['error_aliwebstore_sync_seo_title'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_seo_image'])) {
			$data['error_aliwebstore_sync_seo_image'] = $this->error['aliwebstore_sync_seo_image'];
		} else {
			$data['error_aliwebstore_sync_seo_image'] = '';
		}

		if (isset($this->error['aliwebstore_sync_minimum_commission_rate'])) {
			$data['error_aliwebstore_sync_minimum_commission_rate'] = $this->error['aliwebstore_sync_minimum_commission_rate'];
		} else {
			$data['error_aliwebstore_sync_minimum_commission_rate'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_maximum_commission_rate'])) {
			$data['error_aliwebstore_sync_maximum_commission_rate'] = $this->error['aliwebstore_sync_maximum_commission_rate'];
		} else {
			$data['error_aliwebstore_sync_maximum_commission_rate'] = '';
		}		
		
		if (isset($this->error['aliwebstore_sync_minimum_seller_credit_score'])) {
			$data['error_aliwebstore_sync_minimum_seller_credit_score'] = $this->error['aliwebstore_sync_minimum_seller_credit_score'];
		} else {
			$data['error_aliwebstore_sync_minimum_seller_credit_score'] = '';
		}
		
		if (isset($this->error['aliwebstore_sync_maximum_seller_credit_score'])) {
			$data['error_aliwebstore_sync_maximum_seller_credit_score'] = $this->error['aliwebstore_sync_maximum_seller_credit_score'];
		} else {
			$data['error_aliwebstore_sync_maximum_seller_credit_score'] = '';
		}

		if (isset($this->error['aliwebstore_sync_sort'])) {
			$data['error_aliwebstore_sync_sort'] = $this->error['aliwebstore_sync_sort'];
		} else {
			$data['error_aliwebstore_sync_sort'] = '';
		}
		$data['breadcrumbs'] = array();
		
		$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);
		
		$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
		);
		
		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
					'text' => $this->language->get('heading_title'),
					'href' => $this->url->link('extension/module/aliwebstore_sync', 'token=' . $this->session->data['token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
					'text' => $this->language->get('heading_title'),
					'href' => $this->url->link('extension/module/aliwebstore_sync', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}

		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/aliwebstore_sync', 'token=' . $this->session->data['token'], true);
		} else {
			$data['action'] = $this->url->link('extension/module/aliwebstore_sync', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true);
		}

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
		}

		$data['token'] = $this->session->data['token'];

		if (isset($this->request->post['aliwebstore_sync_cartversion'])) {
			$data['aliwebstore_sync_cartversion'] = $this->request->post['aliwebstore_sync_cartversion'];
		} else {
			$data['aliwebstore_sync_cartversion'] = $this->config->get('aliwebstore_sync_cartversion');
		}
		
		if (isset($this->request->post['aliwebstore_sync_data_sync_url'])) {
			$data['aliwebstore_sync_data_sync_url'] = $this->request->post['aliwebstore_sync_data_sync_url'];
		} else {
			$data['aliwebstore_sync_data_sync_url'] = $this->config->get('aliwebstore_sync_data_sync_url');
		}

		if (isset($this->request->post['aliwebstore_sync_order_subscription_id'])) {
			$data['aliwebstore_sync_order_subscription_id'] = $this->request->post['aliwebstore_sync_order_subscription_id'];
		} else {
			$data['aliwebstore_sync_order_subscription_id'] = $this->config->get('aliwebstore_sync_order_subscription_id');
		}
		
		if (isset($this->request->post['aliwebstore_sync_merchant_id'])) {
			$data['aliwebstore_sync_merchant_id'] = $this->request->post['aliwebstore_sync_merchant_id'];
		} else {
			$data['aliwebstore_sync_merchant_id'] = $merchat_id;
		}
		
		if (isset($this->request->post['aliwebstore_sync_locale'])) {
			$data['aliwebstore_sync_locale'] = $this->request->post['aliwebstore_sync_locale'];
		} else {
			$data['aliwebstore_sync_locale'] = $this->config->get('aliwebstore_sync_locale');	
		}
		
		if (isset($this->request->post['aliwebstore_sync_language'])) {
			$data['aliwebstore_sync_language'] = $this->request->post['aliwebstore_sync_language'];
		} else {
			$data['aliwebstore_sync_language'] = $this->config->get('aliwebstore_sync_language');
		}

		if (isset($this->request->post['aliwebstore_sync_public_key'])) {
			$data['aliwebstore_sync_public_key'] = $this->request->post['aliwebstore_sync_public_key'];
		} else {
			$data['aliwebstore_sync_public_key'] = $this->config->get('aliwebstore_sync_public_key');
		}
		
		if (isset($this->request->post['aliwebstore_sync_private_key'])) {
			$data['aliwebstore_sync_private_key'] = $this->request->post['aliwebstore_sync_private_key'];
		} else {
			$data['aliwebstore_sync_private_key'] = $this->config->get('aliwebstore_sync_private_key');
		}
		
		if (isset($this->request->post['aliwebstore_sync_associate_id'])) {
			$data['aliwebstore_sync_associate_id'] = $this->request->post['aliwebstore_sync_associate_id'];
		} else {
			$data['aliwebstore_sync_associate_id'] = $this->config->get('aliwebstore_sync_associate_id');
		}
		
		if (isset($this->request->post['aliwebstore_sync_item_page'])) {
       		$data['aliwebstore_sync_item_page'] = $this->request->post['aliwebstore_sync_item_page'];
       	} else {
			$data['aliwebstore_sync_item_page'] = $item_page;
		}
			
		if (isset($this->request->post['aliwebstore_sync_keywords'])) {
       		$data['aliwebstore_sync_keywords'] = $this->request->post['aliwebstore_sync_keywords'];
       	} else {
			$data['aliwebstore_sync_keywords'] = $this->config->get('aliwebstore_sync_keywords');
		}
		
		if (isset($this->request->post['aliwebstore_sync_product_category'])) {
			$data['aliwebstore_sync_product_category'] = $this->request->post['aliwebstore_sync_product_category'];
		} else {
			$data['aliwebstore_sync_product_category'] = $this->config->get('aliwebstore_sync_product_category');
		}
		
		if (isset($this->request->post['aliwebstore_sync_minimum_price'])) {
       		$data['aliwebstore_sync_minimum_price'] = $this->request->post['aliwebstore_sync_minimum_price'];
       	} else {
			$data['aliwebstore_sync_minimum_price'] = $minimum_price;
		}
		
		if (isset($this->request->post['aliwebstore_sync_maximum_price'])) {
       		$data['aliwebstore_sync_maximum_price'] = $this->request->post['aliwebstore_sync_maximum_price'];
       	} else {
			$data['aliwebstore_sync_maximum_price'] = $maximum_price;
		}

		if (isset($this->request->post['aliwebstore_sync_minimum_commission_rate'])) {
			$data['aliwebstore_sync_minimum_commission_rate'] = $this->request->post['aliwebstore_sync_minimum_commission_rate'];
		} else {
			$data['aliwebstore_sync_minimum_commission_rate'] = $minimum_commission_rate;
		}
		
		if (isset($this->request->post['aliwebstore_sync_maximum_commission_rate'])) {
			$data['aliwebstore_sync_maximum_commission_rate'] = $this->request->post['aliwebstore_sync_maximum_commission_rate'];
		} else {
			$data['aliwebstore_sync_maximum_commission_rate'] = $maximum_commission_rate;
		}

		if (isset($this->request->post['aliwebstore_sync_minimum_seller_credit_score'])) {
			$data['aliwebstore_sync_minimum_seller_credit_score'] = $this->request->post['aliwebstore_sync_minimum_seller_credit_score'];
		} else {
			$data['aliwebstore_sync_minimum_seller_credit_score'] = $minimum_seller_credit_score;
		}
		
		if (isset($this->request->post['aliwebstore_sync_maximum_seller_credit_score'])) {
			$data['aliwebstore_sync_maximum_seller_credit_score'] = $this->request->post['aliwebstore_sync_maximum_seller_credit_score'];
		} else {
			$data['aliwebstore_sync_maximum_seller_credit_score'] = $maximum_seller_credit_score;
		}
		
		if (isset($this->request->post['aliwebstore_sync_sort'])) {
			$data['aliwebstore_sync_sort'] = $this->request->post['aliwebstore_sync_sort'];
		} else {
			$data['aliwebstore_sync_sort'] = $this->config->get('aliwebstore_sync_sort');
		}
		
		if (isset($this->request->post['aliwebstore_sync_product_category'])) {
			$data['aliwebstore_sync_product_category'] = $this->request->post['aliwebstore_sync_product_category'];
		} else {
			$data['aliwebstore_sync_product_category'] = $this->config->get('aliwebstore_sync_product_category');
		}
		
		if (isset($this->request->post['aliwebstore_sync_item_quantity'])) {
       		$data['aliwebstore_sync_item_quantity'] = $this->request->post['aliwebstore_sync_item_quantity'];
       	} else {
			$data['aliwebstore_sync_item_quantity'] = $this->config->get('aliwebstore_sync_item_quantity');
		}

		$this->load->model('localisation/tax_class');

		$data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();

		if (isset($this->request->post['aliwebstore_sync_tax_class_id'])) {
			$data['aliwebstore_sync_tax_class_id'] = $this->request->post['aliwebstore_sync_tax_class_id'];
		} else {
			$data['aliwebstore_sync_tax_class_id'] = $tax_class_id;
		}

		if (isset($this->request->post['aliwebstore_sync_price_markup'])) {
       		$data['aliwebstore_sync_price_markup'] = $this->request->post['aliwebstore_sync_price_markup'];
       	} else {
			$data['aliwebstore_sync_price_markup'] = $price_markup;
		}
		if (isset($this->request->post['aliwebstore_sync_type'])) {
       		$data['aliwebstore_sync_type'] = $this->request->post['aliwebstore_sync_type'];
       	} else {
			$data['aliwebstore_sync_type'] = $this->config->get('aliwebstore_sync_type');
		}
		if (isset($this->request->post['aliwebstore_sync_high_low'])) {
       		$data['aliwebstore_sync_high_low'] = $this->request->post['aliwebstore_sync_high_low'];
       	} else {
			$data['aliwebstore_sync_high_low'] = $this->config->get('aliwebstore_sync_high_low');
		}

		$this->load->model('localisation/stock_status');
		
		$data['stock_statuses'] = $this->model_localisation_stock_status->getStockStatuses();

		if (isset($this->request->post['aliwebstore_sync_stock_status_id'])) {
			$data['aliwebstore_sync_stock_status_id'] = $this->request->post['aliwebstore_sync_stock_status_id'];
		} else {
			$data['aliwebstore_sync_stock_status_id'] = $stock_status_id;
		}

		if (isset($this->request->post['aliwebstore_sync_update_product'])) {
			$data['aliwebstore_sync_update_product'] = $this->request->post['aliwebstore_sync_update_product'];
		} else {
			$data['aliwebstore_sync_update_product'] = $this->config->get('aliwebstore_sync_update_product');
		}

		if (isset($this->request->post['aliwebstore_sync_update_product_title'])) {
			$data['aliwebstore_sync_update_product_title'] = $this->request->post['aliwebstore_sync_update_product_title'];
		} else {
			$data['aliwebstore_sync_update_product_title'] = $this->config->get('aliwebstore_sync_update_product_title');
		}

		if (isset($this->request->post['aliwebstore_sync_update_product_desc'])) {
			$data['aliwebstore_sync_update_product_desc'] = $this->request->post['aliwebstore_sync_update_product_desc'];
		} else {
			$data['aliwebstore_sync_update_product_desc'] = $this->config->get('aliwebstore_sync_update_product_desc');
		}
		
		if (isset($this->request->post['aliwebstore_sync_update_product_sku'])) {
			$data['aliwebstore_sync_update_product_sku'] = $this->request->post['aliwebstore_sync_update_product_sku'];
		} else {
			$data['aliwebstore_sync_update_product_sku'] = $this->config->get('aliwebstore_sync_update_product_sku');
		}
		
		if (isset($this->request->post['aliwebstore_sync_update_product_upc'])) {
			$data['aliwebstore_sync_update_product_upc'] = $this->request->post['aliwebstore_sync_update_product_upc'];
		} else {
			$data['aliwebstore_sync_update_product_upc'] = $this->config->get('aliwebstore_sync_update_product_upc');
		}

		if (isset($this->request->post['aliwebstore_sync_update_product_price'])) {
			$data['aliwebstore_sync_update_product_price'] = $this->request->post['aliwebstore_sync_update_product_price'];
		} else {
			$data['aliwebstore_sync_update_product_price'] = $this->config->get('aliwebstore_sync_update_product_price');
		}

		if (isset($this->request->post['aliwebstore_sync_update_product_special'])) {
			$data['aliwebstore_sync_update_product_special'] = $this->request->post['aliwebstore_sync_update_product_special'];
		} else {
			$data['aliwebstore_sync_update_product_special'] = $this->config->get('aliwebstore_sync_update_product_special');
		}
		
		if (isset($this->request->post['aliwebstore_sync_update_product_image'])) {
			$data['aliwebstore_sync_update_product_image'] = $this->request->post['aliwebstore_sync_update_product_image'];
		} else {
			$data['aliwebstore_sync_update_product_image'] = $this->config->get('aliwebstore_sync_update_product_image');
		}
		
		if (isset($this->request->post['aliwebstore_sync_update_product_to_category'])) {
			$data['aliwebstore_sync_update_product_to_category'] = $this->request->post['aliwebstore_sync_update_product_to_category'];
		} else {
			$data['aliwebstore_sync_update_product_to_category'] = $this->config->get('aliwebstore_sync_update_product_to_category');
		}
		
		if (isset($this->request->post['aliwebstore_sync_update_product_related'])) {
			$data['aliwebstore_sync_update_product_related'] = $this->request->post['aliwebstore_sync_update_product_related'];
		} else {
			$data['aliwebstore_sync_update_product_related'] = $this->config->get('aliwebstore_sync_update_product_related');
		}

		if (isset($this->request->post['aliwebstore_sync_update_product_specification'])) {
			$data['aliwebstore_sync_update_product_specification'] = $this->request->post['aliwebstore_sync_update_product_specification'];
		} else {
			$data['aliwebstore_sync_update_product_specification'] = $this->config->get('aliwebstore_sync_update_product_specification');
		}
		
		if (isset($this->request->post['aliwebstore_sync_update_product_option'])) {
			$data['aliwebstore_sync_update_product_option'] = $this->request->post['aliwebstore_sync_update_product_option'];
		} else {
			$data['aliwebstore_sync_update_product_option'] = $this->config->get('aliwebstore_sync_update_product_option');
		}
		
		if (isset($this->request->post['aliwebstore_sync_show_extra_product_info'])) {
			$data['aliwebstore_sync_show_extra_product_info'] = $this->request->post['aliwebstore_sync_show_extra_product_info'];
		} else {
			$data['aliwebstore_sync_show_extra_product_info'] = $this->config->get('aliwebstore_sync_show_extra_product_info');
		}

		if (isset($this->request->post['aliwebstore_sync_show_search_by_aliwebstore'])) {
			$data['aliwebstore_sync_show_search_by_aliwebstore'] = $this->request->post['aliwebstore_sync_show_search_by_aliwebstore'];
		} else {
			$data['aliwebstore_sync_show_search_by_aliwebstore'] = $this->config->get('aliwebstore_sync_show_search_by_aliwebstore');
		}

		if (isset($this->request->post['aliwebstore_sync_default_search_by_aliwebstore'])) {
			$data['aliwebstore_sync_default_search_by_aliwebstore'] = $this->request->post['aliwebstore_sync_default_search_by_aliwebstore'];
		} else {
			$data['aliwebstore_sync_default_search_by_aliwebstore'] = $this->config->get('aliwebstore_sync_default_search_by_aliwebstore');
		}
		
		if (isset($this->request->post['aliwebstore_sync_auto_disabled_product'])) {
			$data['aliwebstore_sync_auto_disabled_product'] = $this->request->post['aliwebstore_sync_auto_disabled_product'];
		} else {
			$data['aliwebstore_sync_auto_disabled_product'] = $this->config->get('aliwebstore_sync_auto_disabled_product');
		}

		if (isset($this->request->post['aliwebstore_sync_auto_disabled_product_desc'])) {
			$data['aliwebstore_sync_auto_disabled_product_desc'] = $this->request->post['aliwebstore_sync_auto_disabled_product_desc'];
		} else {
			$data['aliwebstore_sync_auto_disabled_product_desc'] = $aliwebstore_sync_auto_disabled_product_desc;
		}
		
		if (isset($this->request->post['aliwebstore_sync_product_redirect'])) {
			$data['aliwebstore_sync_product_redirect'] = $this->request->post['aliwebstore_sync_product_redirect'];
		} else {
			$data['aliwebstore_sync_product_redirect'] = $this->config->get('aliwebstore_sync_product_redirect');
		}

		if (isset($this->request->post['aliwebstore_sync_seo_title'])) {
       		$data['aliwebstore_sync_seo_title'] = $this->request->post['aliwebstore_sync_seo_title'];
       	} else {
			$data['aliwebstore_sync_seo_title'] = $seo_title;
		}
		
		if (isset($this->request->post['aliwebstore_sync_seo_image'])) {
			$data['aliwebstore_sync_seo_image'] = $this->request->post['aliwebstore_sync_seo_image'];
		} else {
			$data['aliwebstore_sync_seo_image'] = $seo_image;
		}
		
		if (isset($this->request->post['aliwebstore_sync_api_key'])) {
       		$data['aliwebstore_sync_api_key'] = $this->request->post['aliwebstore_sync_api_key'];
       	} else {
			$data['aliwebstore_sync_api_key'] = $this->config->get('aliwebstore_sync_api_key');
		}
		
		if (isset($this->request->post['aliwebstore_sync_enabled_api'])) {
       		$data['aliwebstore_sync_enabled_api'] = $this->request->post['aliwebstore_sync_enabled_api'];
       	} else {
			$data['aliwebstore_sync_enabled_api'] = $this->config->get('aliwebstore_sync_enabled_api');
		}
		
		if (isset($this->request->post['aliwebstore_sync_csv_delimiter'])) {
       		$data['aliwebstore_sync_csv_delimiter'] = $this->request->post['aliwebstore_sync_csv_delimiter'];
       	} else {
				$data['aliwebstore_sync_csv_delimiter'] = $csv_delimiter;
		}
		
		if (isset($this->request->post['aliwebstore_sync_csv_remove'])) {
       		$data['aliwebstore_sync_csv_remove'] = $this->request->post['aliwebstore_sync_csv_remove'];
       	} else {
				$data['aliwebstore_sync_csv_remove'] = $csv_remove;
		}
		
		if (isset($this->request->post['aliwebstore_sync_status'])) {
			$data['aliwebstore_sync_status'] = $this->request->post['aliwebstore_sync_status'];
		} else {
			$data['aliwebstore_sync_status'] = $this->config->get('aliwebstore_sync_status');
		}
		
		if (isset($this->request->post['aliwebstore_sync_debug_mode'])) {
			$data['aliwebstore_sync_debug_mode'] = $this->request->post['aliwebstore_sync_debug_mode'];
		} else {
			$data['aliwebstore_sync_debug_mode'] = $this->config->get('aliwebstore_sync_debug_mode');
		}
		
		if (isset($this->request->post['aliwebstore_sync_server'])) {
			$data['aliwebstore_sync_server'] = $this->request->post['aliwebstore_sync_server'];
		} else {
			$data['aliwebstore_sync_server'] = $this->config->get('aliwebstore_sync_server');
		}
		
		if (isset($this->request->post['aliwebstore_sync_memory_limit'])) {
			$data['aliwebstore_sync_memory_limit'] = $this->request->post['aliwebstore_sync_memory_limit'];
		} else {
			$data['aliwebstore_sync_memory_limit'] = $this->config->get('aliwebstore_sync_memory_limit');
		}

		if (isset($this->request->post['aliwebstore_sync_markup_category'])) {
			$product_categories = explode(',', $this->request->post['aliwebstore_sync_markup_category']);
		} elseif ($this->config->get('aliwebstore_sync_category') != '') {
			$product_categories = explode(',', $this->config->get('aliwebstore_sync_markup_category'));
		} else {
			$product_categories = array();
		}

		if (isset($this->request->post['aliwebstore_sync_module'])) {
			$modules = explode(',', $this->request->post['aliwebstore_sync_module']);
		} elseif ($this->config->get('aliwebstore_sync_module') != '') {
			$modules = explode(',', $this->config->get('aliwebstore_sync_module'));
		} else {
			$modules = array();
		}

		// Retrieve Categories
		$this->load->model('catalog/category');

		$filter_data = array();

		$results = $this->model_catalog_category->getCategories($filter_data);
		
		$data['categories'] = array();

		foreach ($results as $result) {
			$data['categories'][] = array(
				'category_id' => $result['category_id'], 
				'name'        => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
			);
		}
		
		// Retrieve SyncCategories
		$sync_categories = $data['aliwebstore_sync_product_category'];
		
		$data['sync_categories'] = array();
		
		if (!empty($sync_categories)) {
			foreach ($sync_categories as $tid) {
				$category_info = $this->model_datasync_aliwebstore_sync->getSyncCategory($tid);
				
				if ($category_info) {
					$data['sync_categories'][] = array(
						'tid' => $category_info['tid'],
						'name'=> $category_info['name']
					);
				}
			}
		}
		
		// Retrieve the Product Redirect
		$products_redirect =  $data['aliwebstore_sync_product_redirect'];
	
		$data['product_redirect'] = array();
		
		if (!empty($products_redirect)) {
			$this->load->model('catalog/product');
			
			foreach ($products_redirect as $product_id) {
				$product_info = $this->model_catalog_product->getProduct($product_id);
				
				if ($product_info) {
					$data['product_redirect'][] = array(
						'product_id' => $product_info['product_id'],
						'name'       => $product_info['name']
					);
				}
			}
		}

		$data['sync_category_list'] = null;
		//Retrieve the list of sync category and display on the category page
		$data['sync_category_list'] =	$this->getSyncCategoryList($data['aliwebstore_sync_locale']);

		foreach ($product_categories as $category) {
			if (isset($this->request->post['aliwebstore_sync_' . $category . '_category_id'])) {
				$data['aliwebstore_sync_' . $category . '_category_id'] = $this->request->post['aliwebstore_sync_' . $category . '_category_id'];
			} else {
				$data['aliwebstore_sync_' . $category . '_category_id'] = $this->config->get('aliwebstore_sync_' . $category . '_category_id');
			}

			if (isset($this->request->post['aliwebstore_sync_' . $category . '_status'])) {
				$data['aliwebstore_sync_' . $category . '_status'] = $this->request->post['aliwebstore_sync_' . $category . '_status'];
			} else {
				$data['aliwebstore_sync_' . $category . '_status'] = $this->config->get('aliwebstore_sync_' . $category . '_status');
			}

			if (isset($this->request->post['aliwebstore_sync_' . $category . '_price_markup'])) {
				$data['aliwebstore_sync_' . $category . '_price_markup'] = $this->request->post['aliwebstore_sync_' . $category . '_price_markup'];
			} else {
				$data['aliwebstore_sync_' . $category . '_price_markup'] = $this->config->get('aliwebstore_sync_' . $category . '_price_markup');
			}
		}

		$data['product_categories'] = $product_categories;

		if (isset($this->request->post['aliwebstore_sync_markup_category'])) {
			$data['aliwebstore_sync_markup_category'] = $this->request->post['aliwebstore_sync_markup_category'];
		} else {
			$data['aliwebstore_sync_markup_category'] = $this->config->get('aliwebstore_sync_markup_category');
		}


		////New Module
		if (isset($this->request->post['aliwebstore_sync_module'])) {
			$modules = $this->request->post['aliwebstore_sync_module'];
		} elseif ($this->config->has('aliwebstore_sync_module')) {
			$modules = $this->config->get('aliwebstore_sync_module');
		} else {
			$modules = array();
		}
		
		$data['aliwebstore_sync_modules'] = array();
		
		foreach ($modules as $key => $module) {
			$data['aliwebstore_sync_modules'][] = array(
				'key'    => $key,
				'limit'  => $module['limit'],
				'width'  => $module['width'],
				'height' => $module['height']
			);
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/aliwebstore_sync', $data));
	}

	private function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/aliwebstore_sync')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!$this->request->post['aliwebstore_sync_data_sync_url']) {
			$this->error['aliwebstore_sync_data_sync_url'] = $this->language->get('error_aliwebstore_sync_data_sync_url');
			$this->error['warning'] = $this->language->get('error_aliwebstore_sync_data_sync_url');
		}		
		
		if (!$this->request->post['aliwebstore_sync_associate_id']) {
			$this->error['aliwebstore_sync_associate_id'] = $this->language->get('error_aliwebstore_sync_associate_id');
			$this->error['warning'] = $this->language->get('error_aliwebstore_sync_associate_id');
		}
		
		if (!$this->request->post['aliwebstore_sync_public_key']) {
			$this->error['aliwebstore_sync_public_key'] = $this->language->get('error_aliwebstore_sync_public_key');
			$this->error['warning'] = $this->language->get('error_aliwebstore_sync_public_key');
		}
		
		if (!$this->request->post['aliwebstore_sync_private_key']) {
			$this->error['aliwebstore_sync_private_key'] = $this->language->get('error_aliwebstore_sync_private_key');
			$this->error['warning'] = $this->language->get('error_aliwebstore_sync_private_key');
		}
		
		if (!is_numeric($this->request->post['aliwebstore_sync_minimum_price'])) {
			$this->error['aliwebstore_sync_minimum_price'] = $this->language->get('aliwebstore_sync_minimum_price');
			$this->error['warning'] = $this->language->get('error_aliwebstore_sync_minimum_price');
		} else if ((!$this->request->post['aliwebstore_sync_minimum_price']) || ($this->request->post['aliwebstore_sync_minimum_price'] < 0)) {
      		$this->error['aliwebstore_sync_minimum_price'] = $this->language->get('error_aliwebstore_sync_minimum_price');
      		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_minimum_price');
    	}
    	
		if (!is_numeric($this->request->post['aliwebstore_sync_maximum_price'])) {
			$this->error['aliwebstore_sync_maximum_price'] = $this->language->get('aliwebstore_sync_maximum_price');
			$this->error['warning'] = $this->language->get('error_aliwebstore_sync_maximum_price');
		} else if ((!$this->request->post['aliwebstore_sync_maximum_price']) || ($this->request->post['aliwebstore_sync_maximum_price'] > 1000000)) {
      		$this->error['aliwebstore_sync_maximum_price'] = $this->language->get('error_aliwebstore_sync_maximum_price');
      		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_maximum_price');
    	}
    	
    	
    	if (!is_numeric($this->request->post['aliwebstore_sync_minimum_commission_rate'])) {
    		$this->error['aliwebstore_sync_minimum_commission_rate'] = $this->language->get('aliwebstore_sync_minimum_commission_rate');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_minimum_commission_rate');
    	} else if ((!$this->request->post['aliwebstore_sync_minimum_commission_rate']) || ($this->request->post['aliwebstore_sync_minimum_commission_rate'] < 0)) {
    		$this->error['aliwebstore_sync_minimum_commission_rate'] = $this->language->get('error_aliwebstore_sync_minimum_commission_rate');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_minimum_commission_rate');
    	}
    	 
    	if (!is_numeric($this->request->post['aliwebstore_sync_maximum_commission_rate'])) {
    		$this->error['aliwebstore_sync_maximum_commission_rate'] = $this->language->get('aliwebstore_sync_maximum_commission_rate');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_maximum_commission_rate');
    	} else if ((!$this->request->post['aliwebstore_sync_maximum_commission_rate']) || ($this->request->post['aliwebstore_sync_maximum_commission_rate'] > 100)) {
    		$this->error['aliwebstore_sync_maximum_commission_rate'] = $this->language->get('error_aliwebstore_sync_maximum_commission_rate');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_maximum_commission_rate');
    	}
    	
    	if (!is_numeric($this->request->post['aliwebstore_sync_minimum_seller_credit_score'])) {
    		$this->error['aliwebstore_sync_minimum_seller_credit_score'] = $this->language->get('aliwebstore_sync_minimum_seller_credit_score');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_minimum_seller_credit_score');
    	} else if ((!$this->request->post['aliwebstore_sync_minimum_seller_credit_score']) || ($this->request->post['aliwebstore_sync_minimum_seller_credit_score'] < 0)) {
    		$this->error['aliwebstore_sync_minimum_seller_credit_score'] = $this->language->get('error_aliwebstore_sync_minimum_seller_credit_score');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_minimum_seller_credit_score');
    	}
    	
    	if (!is_numeric($this->request->post['aliwebstore_sync_maximum_seller_credit_score'])) {
    		$this->error['aliwebstore_sync_maximum_seller_credit_score'] = $this->language->get('aliwebstore_sync_maximum_seller_credit_score');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_maximum_seller_credit_score');
    	} else if ((!$this->request->post['aliwebstore_sync_maximum_seller_credit_score']) || ($this->request->post['aliwebstore_sync_maximum_seller_credit_score'] > 1000)) {
    		$this->error['aliwebstore_sync_maximum_seller_credit_score'] = $this->language->get('error_aliwebstore_sync_maximum_seller_credit_score');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_maximum_seller_credit_score');
    	}

		if (!is_numeric($this->request->post['aliwebstore_sync_item_quantity'])) {
      		$this->error['aliwebstore_sync_item_quantity'] = $this->language->get('error_aliwebstore_sync_is_number_only');
      		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_is_number_only');
    	} else if ($this->request->post['aliwebstore_sync_item_quantity'] < 0) {
      		$this->error['aliwebstore_sync_item_quantity'] = $this->language->get('error_aliwebstore_sync_item_quantity');
      		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_item_quantity');
    	}

		if (!is_numeric($this->request->post['aliwebstore_sync_price_markup'])) {
      		$this->error['aliwebstore_sync_price_markup'] = $this->language->get('error_aliwebstore_sync_is_number_only');
      		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_is_number_only');
    	/*} else if ($this->request->post['aliwebstore_sync_price_markup'] < 0 || $this->request->post['aliwebstore_sync_price_markup'] > 100) {
      		$this->error['aliwebstore_sync_price_markup'] = $this->language->get('error_aliwebstore_sync_price_markup');
      		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_price_markup');
      	*/	
    	}

    	if (!is_numeric($this->request->post['aliwebstore_sync_seo_title'])) {
    		$this->error['aliwebstore_sync_seo_title'] = $this->language->get('error_aliwebstore_sync_seo_title');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_seo_title');
    	} else if ($this->request->post['aliwebstore_sync_seo_title'] < 1) {
    		$this->error['aliwebstore_sync_seo_title'] = $this->language->get('error_aliwebstore_sync_seo_title');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_seo_title');
    	}
    	
    	if (!is_numeric($this->request->post['aliwebstore_sync_seo_image'])) {
    		$this->error['aliwebstore_sync_seo_image'] = $this->language->get('error_aliwebstore_sync_seo_image');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_seo_image');
    	} else if ($this->request->post['aliwebstore_sync_seo_image'] < 1) {
    		$this->error['aliwebstore_sync_seo_image'] = $this->language->get('error_aliwebstore_sync_seo_image');
    		$this->error['warning'] = $this->language->get('error_aliwebstore_sync_seo_image');
    	}
		
		return !$this->error;
	}
	
	public function getSyncCategoryList($locale = 'aliexpress') {
		$sync_categories = '';
		
		$this->load->model('datasync/aliwebstore_sync');
	
		$filter_data = array('locale' => $locale, 
							 'order_by' => 'tid');
		
		$results = $this->model_datasync_aliwebstore_sync->getSyncCategories($filter_data);

		$count = 0;
		foreach ($results as $result) {
				if ($count == 0) {
					$count++;		
					$sync_categories .= strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'));
				} else {
					$sync_categories .= ", ". strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'));
				}
		}		
		
		return $sync_categories;	
	}
	
	public function autocomplete() {
		$json = array();
		
		if (isset($this->request->get['filter_name'])) {
			$this->load->model('datasync/aliwebstore_sync');
		
			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'locale' => $this->request->get['locale'],
				'order_by' => 'tid',
				'start'       => 0,
				'limit'       => 20
			);
			
			$results = $this->model_datasync_aliwebstore_sync->getSyncCategories($filter_data);
				
			foreach ($results as $result) {
				$json[] = array(
					'tid' => $result['tid'], 
					'name'        => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}		
		}

		$sort_order = array();
	  
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function install() {
		$this->load->model('datasync/aliwebstore_sync');
		$this->model_datasync_aliwebstore_sync->createDataSyncTables();
	}

	public function uninstall() {
		//Do not uninstalled since we need to keep track the sync records in database
		$this->load->model('datasync/aliwebstore_sync');
		$this->model_datasync_aliwebstore_sync->dropDataSyncTables();
	}

	/**
	 * Send the request to Web Servces via Curl
	 * $parameters		-	Array Object
	 * $return			-	Return Object
	 */
	protected function callWebServicesNoReturn($url, $method = 'POST', $params, $port = 443) {
	
		$connection_timeout = 50;
	
		$data = http_build_query($params, '', '&');
	
		// Open a curl session for making the call
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_PORT, $port);
		curl_setopt($curl, CURLOPT_POST, TRUE);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	
		// Tell curl not to return headers, but do return the response
		curl_setopt($curl, CURLOPT_HEADER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, FALSE);
		curl_setopt($curl, CURLOPT_ENCODING, 'UTF-8');
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $connection_timeout);
		curl_setopt($curl, CURLOPT_TIMEOUT, 300);
	
		//spoof information
		$agents = array(
				'Mozilla/5.0 (X11; Linux x86_64; rv:12.0) Gecko/20100101 Firefox/12.0',
				'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:7.0.1) Gecko/20100101 Firefox/7.0.1',
				'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.9) Gecko/20100508 SeaMonkey/2.0.4',
				'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)',
				'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; da-dk) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1'
	
		);
		curl_setopt($curl, CURLOPT_USERAGENT,$agents[array_rand($agents)]);
	
		curl_exec($curl);
	
		curl_close($curl);
	}
}
?>
